package com.example.madmidterm

import com.example.madmidterm.model.Student
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StudentModelTest {

    @Test
    fun testStudentCreation_case1_major() {
        val student = Student(
            studentId = "2501999999",
            name = "John Doe",
            major = "Informatics",
            isEnrolled = false
        )

        assertEquals("2501999999", student.studentId)
        assertEquals("John Doe", student.name)
        assertEquals("Informatics", student.major)
        assertFalse(student.isEnrolled)
    }

    @Test
    fun testStudentCreation_case2_enrollment() {
        val student = Student(
            studentId = "2501888888",
            name = "Jane Smith",
            major = null,
            isEnrolled = true
        )

        assertEquals("2501888888", student.studentId)
        assertEquals("Jane Smith", student.name)
        assertEquals(null, student.major)
        assertTrue(student.isEnrolled)
    }
}
