package com.example.madmidterm.model

data class Student(
    val studentId: String,
    val name: String,
    val major: String? = null,
    val isEnrolled: Boolean = false
)
