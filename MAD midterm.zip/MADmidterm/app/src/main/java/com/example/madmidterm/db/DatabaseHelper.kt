package com.example.madmidterm.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.madmidterm.model.Student

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "StudentDB.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_NAME = "students"
        const val COLUMN_STUDENT_ID = "student_id"
        const val COLUMN_NAME = "student_name"
        const val COLUMN_MAJOR = "major"
        const val COLUMN_ENROLLED = "is_enrolled"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableStatement = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_STUDENT_ID TEXT PRIMARY KEY,
                $COLUMN_NAME TEXT NOT NULL,
                $COLUMN_MAJOR TEXT,
                $COLUMN_ENROLLED INTEGER DEFAULT 0
            )
        """.trimIndent()
        db.execSQL(createTableStatement)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun isStudentIdExists(studentId: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME,
            arrayOf(COLUMN_STUDENT_ID),
            "$COLUMN_STUDENT_ID = ?",
            arrayOf(studentId.trim()),
            null, null, null
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun addStudent(student: Student): Boolean {
        val db = writableDatabase
        if (isStudentIdExists(student.studentId)) {
            return false
        }
        val values = ContentValues().apply {
            put(COLUMN_STUDENT_ID, student.studentId.trim())
            put(COLUMN_NAME, student.name.trim())
            put(COLUMN_MAJOR, student.major)
            put(COLUMN_ENROLLED, if (student.isEnrolled) 1 else 0)
        }
        val result = db.insert(TABLE_NAME, null, values)
        return result != -1L
    }

    fun updateStudent(student: Student): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, student.name.trim())
            put(COLUMN_MAJOR, student.major)
            put(COLUMN_ENROLLED, if (student.isEnrolled) 1 else 0)
        }
        val rowsAffected = db.update(
            TABLE_NAME,
            values,
            "$COLUMN_STUDENT_ID = ?",
            arrayOf(student.studentId.trim())
        )
        return rowsAffected > 0
    }

    fun deleteStudent(studentId: String): Boolean {
        val db = writableDatabase
        val rowsDeleted = db.delete(
            TABLE_NAME,
            "$COLUMN_STUDENT_ID = ?",
            arrayOf(studentId.trim())
        )
        return rowsDeleted > 0
    }

    fun getAllStudents(): List<Student> {
        val studentList = mutableListOf<Student>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)

        if (cursor.moveToFirst()) {
            val idIndex = cursor.getColumnIndexOrThrow(COLUMN_STUDENT_ID)
            val nameIndex = cursor.getColumnIndexOrThrow(COLUMN_NAME)
            val majorIndex = cursor.getColumnIndexOrThrow(COLUMN_MAJOR)
            val enrolledIndex = cursor.getColumnIndexOrThrow(COLUMN_ENROLLED)

            do {
                val id = cursor.getString(idIndex)
                val name = cursor.getString(nameIndex)
                val major = cursor.getString(majorIndex)
                val isEnrolled = cursor.getInt(enrolledIndex) == 1

                studentList.add(
                    Student(
                        studentId = id,
                        name = name,
                        major = major,
                        isEnrolled = isEnrolled
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        return studentList
    }

    fun getStudentById(studentId: String): Student? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_NAME,
            null,
            "$COLUMN_STUDENT_ID = ?",
            arrayOf(studentId.trim()),
            null, null, null
        )

        var student: Student? = null
        if (cursor.moveToFirst()) {
            val id = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STUDENT_ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
            val major = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MAJOR))
            val isEnrolled = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ENROLLED)) == 1

            student = Student(studentId = id, name = name, major = major, isEnrolled = isEnrolled)
        }
        cursor.close()
        return student
    }
}
