package com.example.madmidterm

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.madmidterm.db.DatabaseHelper
import com.example.madmidterm.model.Student
import com.example.madmidterm.ui.theme.MADMidtermTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MADMidtermTheme {
                StudentAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAppScreen() {
    val context = LocalContext.current
    val dbHelper = remember { DatabaseHelper(context) }

    var studentName by remember { mutableStateOf("") }
    var studentId by remember { mutableStateOf("") }
    var selectedMajor by remember { mutableStateOf("Informatics") }
    var isEnrolled by remember { mutableStateOf(false) }

    // Tab mode: 0 for Case 1 (Major Dropdown), 1 for Case 2 (Enrolled Checkbox)
    var selectedTabMode by remember { mutableStateOf(0) }

    var studentList by remember { mutableStateOf(listOf<Student>()) }
    var showViewDialog by remember { mutableStateOf(false) }

    val majorOptions = listOf("Informatics", "Information Systems")
    var dropdownExpanded by remember { mutableStateOf(false) }

    // Helper to refresh student list from SQLite database
    fun refreshList() {
        studentList = dbHelper.getAllStudents()
    }

    LaunchedEffect(Unit) {
        refreshList()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Student Database Management") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mode selector tabs for Case 1 and Case 2 options
            TabRow(
                selectedTabIndex = selectedTabMode,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTabMode == 0,
                    onClick = { selectedTabMode = 0 },
                    text = { Text("Major Mode") }
                )
                Tab(
                    selected = selectedTabMode == 1,
                    onClick = { selectedTabMode = 1 },
                    text = { Text("Enrollment Mode") }
                )
            }

            // Input Form Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Enter Student Name Field
                    OutlinedTextField(
                        value = studentName,
                        onValueChange = { studentName = it },
                        label = { Text("Enter Student Name") },
                        placeholder = { Text("Enter Student Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Enter Student ID Field
                    OutlinedTextField(
                        value = studentId,
                        onValueChange = { studentId = it },
                        label = { Text("Enter Student ID") },
                        placeholder = { Text("Enter Student ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Case 1: Dropdown/Spinner for Major Selection
                    if (selectedTabMode == 0) {
                        ExposedDropdownMenuBox(
                            expanded = dropdownExpanded,
                            onExpandedChange = { dropdownExpanded = !dropdownExpanded },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = selectedMajor,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Major") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false }
                            ) {
                                majorOptions.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option) },
                                        onClick = {
                                            selectedMajor = option
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Case 2: Checkbox for Enrollment Status
                    if (selectedTabMode == 1) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isEnrolled = !isEnrolled }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = isEnrolled,
                                onCheckedChange = { isEnrolled = it }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Has Enrolled",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            }

            // Buttons Section: ADD, EDIT, DELETE, VIEW
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // ADD Button
                Button(
                    onClick = {
                        val nameInput = studentName.trim()
                        val idInput = studentId.trim()

                        if (nameInput.isEmpty() || idInput.isEmpty()) {
                            Toast.makeText(context, "Please enter Student Name and Student ID!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        if (dbHelper.isStudentIdExists(idInput)) {
                            Toast.makeText(context, "Error: Student ID '$idInput' already exists! Student ID must be unique.", Toast.LENGTH_LONG).show()
                            return@Button
                        }

                        val student = Student(
                            studentId = idInput,
                            name = nameInput,
                            major = if (selectedTabMode == 0) selectedMajor else null,
                            isEnrolled = if (selectedTabMode == 1) isEnrolled else false
                        )

                        val success = dbHelper.addStudent(student)
                        if (success) {
                            Toast.makeText(context, "Student added successfully!", Toast.LENGTH_SHORT).show()
                            studentName = ""
                            studentId = ""
                            refreshList()
                        } else {
                            Toast.makeText(context, "Error: Failed to add student. Ensure ID is unique.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ADD", fontSize = 12.sp)
                }

                // EDIT Button
                Button(
                    onClick = {
                        val nameInput = studentName.trim()
                        val idInput = studentId.trim()

                        if (idInput.isEmpty()) {
                            Toast.makeText(context, "Please enter Student ID to EDIT!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        if (!dbHelper.isStudentIdExists(idInput)) {
                            Toast.makeText(context, "Error: Student ID '$idInput' not found!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val existingStudent = dbHelper.getStudentById(idInput)
                        val updatedStudent = Student(
                            studentId = idInput,
                            name = nameInput.ifEmpty { existingStudent?.name ?: "" },
                            major = if (selectedTabMode == 0) selectedMajor else existingStudent?.major,
                            isEnrolled = if (selectedTabMode == 1) isEnrolled else (existingStudent?.isEnrolled ?: false)
                        )

                        val success = dbHelper.updateStudent(updatedStudent)
                        if (success) {
                            Toast.makeText(context, "Student updated successfully!", Toast.LENGTH_SHORT).show()
                            refreshList()
                        } else {
                            Toast.makeText(context, "Error updating student!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("EDIT", fontSize = 12.sp)
                }

                // DELETE Button
                Button(
                    onClick = {
                        val idInput = studentId.trim()

                        if (idInput.isEmpty()) {
                            Toast.makeText(context, "Please enter Student ID to DELETE!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        if (!dbHelper.isStudentIdExists(idInput)) {
                            Toast.makeText(context, "Error: Student ID '$idInput' not found!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val success = dbHelper.deleteStudent(idInput)
                        if (success) {
                            Toast.makeText(context, "Student deleted successfully!", Toast.LENGTH_SHORT).show()
                            studentName = ""
                            studentId = ""
                            refreshList()
                        } else {
                            Toast.makeText(context, "Error deleting student!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("DELETE", fontSize = 11.sp)
                }

                // VIEW Button
                Button(
                    onClick = {
                        refreshList()
                        showViewDialog = true
                        Toast.makeText(context, "Found ${studentList.size} student record(s)", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("VIEW", fontSize = 12.sp)
                }
            }

            // Student Database Records List View
            Text(
                text = "Stored Records (${studentList.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (studentList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No students in database.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(studentList, key = { it.studentId }) { student ->
                        StudentItemCard(
                            student = student,
                            onClick = {
                                studentId = student.studentId
                                studentName = student.name
                                student.major?.let { selectedMajor = it }
                                isEnrolled = student.isEnrolled
                            }
                        )
                    }
                }
            }
        }
    }

    // VIEW Dialog showing full list of records
    if (showViewDialog) {
        AlertDialog(
            onDismissRequest = { showViewDialog = false },
            title = { Text("Database View (${studentList.size} Students)") },
            text = {
                if (studentList.isEmpty()) {
                    Text("Database is empty.")
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 400.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(studentList) { student ->
                            StudentItemCard(
                                student = student,
                                onClick = {
                                    studentId = student.studentId
                                    studentName = student.name
                                    student.major?.let { selectedMajor = it }
                                    isEnrolled = student.isEnrolled
                                    showViewDialog = false
                                }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showViewDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun StudentItemCard(student: Student, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ID: ${student.studentId}",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (student.isEnrolled) "Enrolled" else "Not Enrolled",
                    color = if (student.isEnrolled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
            }
            Text(
                text = "Name: ${student.name}",
                style = MaterialTheme.typography.bodyMedium
            )
            if (!student.major.isNullOrEmpty()) {
                Text(
                    text = "Major: ${student.major}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
